"""
=============================================================================
Self-Care Activity Scheduling and Emotional Balance Survey
=============================================================================
Course:      Fundamentals of Programming
Topic 151:   Self-Care Activity Scheduling and Emotional Balance
Version:     1.1 (GUI - Tkinter)

Description:
    A psychological survey application that assesses how individuals
    schedule and engage in self-care activities across multiple domains
    (physical, emotional, social, cognitive, structural) and evaluates
    the resulting impact on their emotional balance and overall wellbeing.

Architecture:
    This program follows the Input -> Process -> Output (IPO) model:
      - INPUT:   Collect personal details and survey responses from user
      - PROCESS: Validate inputs, compute scores, interpret results
      - OUTPUT:  Display results on screen and persist to JSON file

Design Principles (from Lecture Week 11):
    - Modular design: separate functions for each concern
    - Error handling: try/except blocks for robustness
    - JSON persistence: save and load survey results
    - Input validation: validate all user data before processing
    - Unit testing: testable helper functions (run with --test flag)
=============================================================================
"""

import json
import os
import sys
import unittest
from datetime import datetime

# Tkinter is only needed for the GUI; tests can run without it
try:
    import tkinter as tk
    from tkinter import ttk, messagebox, filedialog
    TKINTER_AVAILABLE = True
except ImportError:
    TKINTER_AVAILABLE = False


# =============================================================================
# SECTION 1: SURVEY DATA (Questions and Psychological States)
# =============================================================================
# 20 original questions, each with 5 answer options scored 0–4.
# Questions are grouped thematically across self-care domains inspired by
# the Mindful Self-Care Scale (Cook-Cottone & Guyker, 2018) domains:
# Physical Care, Mindful Relaxation, Supportive Structure,
# Supportive Relationships, Mindful Awareness, Self-Compassion & Purpose.

VERSION = 1.1

QUESTIONS = [
    # --- Domain: Physical Self-Care (Q1–Q4) ---
    {
        "id": 1,
        "domain": "Physical Self-Care",
        "question": "How often do you set aside dedicated time for physical "
                    "self-care activities (e.g., exercise, stretching, yoga)?",
        "options": [
            ("Every day", 0),
            ("Several times a week", 1),
            ("Once a week", 2),
            ("Rarely", 3),
            ("Never", 4)
        ]
    },
    {
        "id": 2,
        "domain": "Physical Self-Care",
        "question": "How well do you manage to get 7–9 hours of quality "
                    "sleep on most nights?",
        "options": [
            ("Always", 0),
            ("Most nights", 1),
            ("About half the time", 2),
            ("Rarely", 3),
            ("Almost never", 4)
        ]
    },
    {
        "id": 3,
        "domain": "Physical Self-Care",
        "question": "How often do you eat balanced, nutritious meals at "
                    "regular times during the day?",
        "options": [
            ("Always", 0),
            ("Usually", 1),
            ("Sometimes", 2),
            ("Rarely", 3),
            ("Almost never", 4)
        ]
    },
    {
        "id": 4,
        "domain": "Physical Self-Care",
        "question": "How often do you engage in nature-based activities "
                    "(e.g., outdoor walks, gardening, park visits)?",
        "options": [
            ("Daily", 0),
            ("Several times a week", 1),
            ("Weekly", 2),
            ("Rarely", 3),
            ("Never", 4)
        ]
    },
    # --- Domain: Mindful Relaxation (Q5–Q7) ---
    {
        "id": 5,
        "domain": "Mindful Relaxation",
        "question": "How frequently do you practice mindfulness, meditation, "
                    "or deep-breathing exercises to manage your emotions?",
        "options": [
            ("Daily", 0),
            ("Several times a week", 1),
            ("Occasionally", 2),
            ("Rarely", 3),
            ("Never", 4)
        ]
    },
    {
        "id": 6,
        "domain": "Mindful Relaxation",
        "question": "How often do you spend quality time on hobbies or "
                    "creative activities that bring you joy and relaxation?",
        "options": [
            ("Daily", 0),
            ("A few times a week", 1),
            ("Weekly", 2),
            ("Rarely", 3),
            ("Never", 4)
        ]
    },
    {
        "id": 7,
        "domain": "Mindful Relaxation",
        "question": "How often do you deliberately limit screen time "
                    "(social media, news) to protect your mental health?",
        "options": [
            ("Always", 0),
            ("Often", 1),
            ("Sometimes", 2),
            ("Rarely", 3),
            ("Never", 4)
        ]
    },
    # --- Domain: Supportive Structure (Q8–Q11) ---
    {
        "id": 8,
        "domain": "Supportive Structure",
        "question": "How well do you maintain a consistent daily routine "
                    "that includes planned time for rest and relaxation?",
        "options": [
            ("Very well", 0),
            ("Well", 1),
            ("Moderately", 2),
            ("Poorly", 3),
            ("Not at all", 4)
        ]
    },
    {
        "id": 9,
        "domain": "Supportive Structure",
        "question": "How well do you plan your weekly schedule to include "
                    "both productive tasks and self-care activities?",
        "options": [
            ("Very well", 0),
            ("Well", 1),
            ("Moderately", 2),
            ("Poorly", 3),
            ("Not at all", 4)
        ]
    },
    {
        "id": 10,
        "domain": "Supportive Structure",
        "question": "How often do you take short breaks during prolonged "
                    "periods of work or study?",
        "options": [
            ("Every 30–60 minutes", 0),
            ("Every 1–2 hours", 1),
            ("Every few hours", 2),
            ("Rarely", 3),
            ("Never", 4)
        ]
    },
    {
        "id": 11,
        "domain": "Supportive Structure",
        "question": "How satisfied are you with the balance between your "
                    "responsibilities and personal time?",
        "options": [
            ("Very satisfied", 0),
            ("Satisfied", 1),
            ("Neutral", 2),
            ("Dissatisfied", 3),
            ("Very dissatisfied", 4)
        ]
    },
    # --- Domain: Supportive Relationships (Q12–Q14) ---
    {
        "id": 12,
        "domain": "Supportive Relationships",
        "question": "How frequently do you connect with friends or family "
                    "members for emotional support and companionship?",
        "options": [
            ("Daily", 0),
            ("Several times a week", 1),
            ("Weekly", 2),
            ("A few times a month", 3),
            ("Rarely or never", 4)
        ]
    },
    {
        "id": 13,
        "domain": "Supportive Relationships",
        "question": "How comfortable do you feel asking others for help "
                    "when you are feeling overwhelmed or stressed?",
        "options": [
            ("Very comfortable", 0),
            ("Comfortable", 1),
            ("Somewhat comfortable", 2),
            ("Uncomfortable", 3),
            ("Very uncomfortable", 4)
        ]
    },
    {
        "id": 14,
        "domain": "Supportive Relationships",
        "question": "How often do you participate in group or community "
                    "activities (clubs, volunteering, group sports)?",
        "options": [
            ("Weekly or more", 0),
            ("A few times a month", 1),
            ("Monthly", 2),
            ("Rarely", 3),
            ("Never", 4)
        ]
    },
    # --- Domain: Mindful Awareness (Q15–Q17) ---
    {
        "id": 15,
        "domain": "Mindful Awareness",
        "question": "How would you rate your ability to recognise when you "
                    "need a break from work or study before burnout?",
        "options": [
            ("Excellent", 0),
            ("Good", 1),
            ("Average", 2),
            ("Below average", 3),
            ("Very poor", 4)
        ]
    },
    {
        "id": 16,
        "domain": "Mindful Awareness",
        "question": "How often do you write in a journal or use another "
                    "method to reflect on your emotions and experiences?",
        "options": [
            ("Daily", 0),
            ("A few times a week", 1),
            ("Weekly", 2),
            ("Rarely", 3),
            ("Never", 4)
        ]
    },
    {
        "id": 17,
        "domain": "Mindful Awareness",
        "question": "How often do you experience sudden mood swings or "
                    "periods of emotional instability?",
        "options": [
            ("Never", 0),
            ("Rarely", 1),
            ("Sometimes", 2),
            ("Frequently", 3),
            ("Very frequently", 4)
        ]
    },
    # --- Domain: Self-Compassion & Purpose (Q18–Q20) ---
    {
        "id": 18,
        "domain": "Self-Compassion and Purpose",
        "question": "How confident are you in your ability to cope with "
                    "unexpected stressful events in a healthy way?",
        "options": [
            ("Very confident", 0),
            ("Confident", 1),
            ("Somewhat confident", 2),
            ("Not very confident", 3),
            ("Not confident at all", 4)
        ]
    },
    {
        "id": 19,
        "domain": "Self-Compassion and Purpose",
        "question": "How often do you feel a sense of accomplishment, "
                    "meaning, and purpose at the end of each day?",
        "options": [
            ("Almost always", 0),
            ("Often", 1),
            ("Sometimes", 2),
            ("Rarely", 3),
            ("Never", 4)
        ]
    },
    {
        "id": 20,
        "domain": "Self-Compassion and Purpose",
        "question": "How would you rate your overall emotional stability "
                    "and sense of inner balance over the past month?",
        "options": [
            ("Excellent", 0),
            ("Good", 1),
            ("Fair", 2),
            ("Poor", 3),
            ("Very poor", 4)
        ]
    }
]

# 6 psychological states based on total score (max = 20 * 4 = 80)
PSYCH_STATES = {
    "Excellent Emotional Balance":      (0, 13),
    "Good Emotional Balance":           (14, 26),
    "Moderate Emotional Balance":       (27, 40),
    "Mild Emotional Imbalance":         (41, 53),
    "Significant Emotional Imbalance":  (54, 66),
    "Critical Emotional Imbalance":     (67, 80)
}

STATE_DESCRIPTIONS = {
    "Excellent Emotional Balance":
        "You demonstrate outstanding self-care scheduling habits and "
        "excellent emotional regulation. Your routine effectively supports "
        "your wellbeing across all domains. Keep maintaining these healthy "
        "practices!",
    "Good Emotional Balance":
        "You manage your self-care activities and emotions well overall. "
        "Minor adjustments to your scheduling could further strengthen "
        "your emotional resilience and daily balance.",
    "Moderate Emotional Balance":
        "Your emotional balance is at a moderate level. Consider building "
        "more structured and consistent self-care activities into your "
        "weekly routine to improve stability.",
    "Mild Emotional Imbalance":
        "You are experiencing some signs of emotional imbalance. It is "
        "recommended to create a more deliberate daily self-care schedule "
        "and to prioritise rest, social connection, and relaxation.",
    "Significant Emotional Imbalance":
        "Your self-care routines need significant attention. Consider "
        "seeking support from a counsellor or trusted person and building "
        "a dedicated daily self-care schedule across physical, emotional, "
        "and social domains.",
    "Critical Emotional Imbalance":
        "Your emotional wellbeing requires immediate attention. Please "
        "reach out to a mental health professional, counsellor, or trusted "
        "person for support. Structured self-care intervention is strongly "
        "recommended."
}

STATE_COLOURS = {
    "Excellent Emotional Balance":      "#27AE60",
    "Good Emotional Balance":           "#2ECC71",
    "Moderate Emotional Balance":       "#F39C12",
    "Mild Emotional Imbalance":         "#E67E22",
    "Significant Emotional Imbalance":  "#E74C3C",
    "Critical Emotional Imbalance":     "#C0392B"
}


# =============================================================================
# SECTION 2: INPUT FUNCTIONS — Validation
# =============================================================================
# These functions handle the INPUT stage of the IPO model.
# They validate user-provided data before any processing occurs.

def validate_name(name: str) -> bool:
    """
    Validate that a name is non-empty and contains no digits.

    Args:
        name: The name string to validate.

    Returns:
        True if the name is valid, False otherwise.
    """
    stripped = name.strip()
    if len(stripped) == 0:
        return False
    if any(char.isdigit() for char in stripped):
        return False
    return True


def validate_date_of_birth(dob_str: str) -> bool:
    """
    Validate that a date string is in YYYY-MM-DD format and is in the past.

    Args:
        dob_str: The date string to validate.

    Returns:
        True if the date is valid and in the past, False otherwise.
    """
    try:
        parsed_date = datetime.strptime(dob_str.strip(), "%Y-%m-%d")
        if parsed_date >= datetime.now():
            return False
        return True
    except ValueError:
        return False


def validate_student_id(sid: str) -> bool:
    """
    Validate that the student ID consists only of digits and is non-empty.

    Args:
        sid: The student ID string to validate.

    Returns:
        True if the student ID is valid, False otherwise.
    """
    stripped = sid.strip()
    if len(stripped) == 0:
        return False
    return stripped.isdigit()


# =============================================================================
# SECTION 3: PROCESS FUNCTIONS — Score Calculation and Interpretation
# =============================================================================
# These functions handle the PROCESS stage of the IPO model.
# They compute scores and determine the psychological state.

def calculate_total_score(answer_scores: list) -> int:
    """
    Calculate the total survey score from a list of individual scores.

    Args:
        answer_scores: A list of integer scores (one per question).

    Returns:
        The sum of all scores.

    Raises:
        ValueError: If the list is empty or contains non-integer values.
    """
    if not answer_scores:
        raise ValueError("Answer scores list cannot be empty.")
    if not all(isinstance(s, int) for s in answer_scores):
        raise ValueError("All scores must be integers.")
    return sum(answer_scores)


def interpret_score(total_score: int) -> str:
    """
    Interpret the total score and return the corresponding psychological state.

    Args:
        total_score: The total survey score.

    Returns:
        A string describing the psychological state.
    """
    for state_name, (low, high) in PSYCH_STATES.items():
        if low <= total_score <= high:
            return state_name
    return "Unknown"


def get_state_description(state_name: str) -> str:
    """
    Return the detailed description for a given psychological state.

    Args:
        state_name: The name of the psychological state.

    Returns:
        A descriptive string, or a default message if state is unknown.
    """
    return STATE_DESCRIPTIONS.get(state_name, "No description available.")


def calculate_domain_scores(answers: list) -> dict:
    """
    Calculate average scores per self-care domain for detailed feedback.

    Args:
        answers: A list of answer dictionaries with 'domain' and 'score' keys.

    Returns:
        A dictionary mapping domain names to average scores.
    """
    domain_totals = {}
    domain_counts = {}
    for answer in answers:
        domain = answer.get("domain", "Unknown")
        score = answer.get("score", 0)
        domain_totals[domain] = domain_totals.get(domain, 0) + score
        domain_counts[domain] = domain_counts.get(domain, 0) + 1

    domain_averages = {}
    for domain in domain_totals:
        if domain_counts[domain] > 0:
            avg = domain_totals[domain] / domain_counts[domain]
            domain_averages[domain] = round(avg, 2)
    return domain_averages


# =============================================================================
# SECTION 4: OUTPUT FUNCTIONS — JSON Persistence
# =============================================================================
# These functions handle the OUTPUT stage of the IPO model.
# They save results to JSON files and load previous results.

def save_results_to_json(filepath: str, data: dict) -> bool:
    """
    Save survey results to a JSON file with error handling.

    Args:
        filepath: The path where the JSON file should be saved.
        data: The dictionary of results to save.

    Returns:
        True if saved successfully, False otherwise.
    """
    try:
        with open(filepath, "w", encoding="utf-8") as file:
            json.dump(data, file, indent=4, ensure_ascii=False, sort_keys=False)
        return True
    except (IOError, PermissionError, TypeError) as error:
        print(f"Error saving results: {error}")
        return False


def load_results_from_json(filepath: str) -> dict:
    """
    Load survey results from a JSON file with error handling.

    Args:
        filepath: The path of the JSON file to load.

    Returns:
        A dictionary of results, or an empty dict if loading fails.
    """
    try:
        with open(filepath, "r", encoding="utf-8") as file:
            return json.load(file)
    except (FileNotFoundError, json.JSONDecodeError, IOError) as error:
        print(f"Error loading results: {error}")
        return {}


def build_result_record(name, surname, dob, student_id,
                        answers, total_score, state, description,
                        domain_scores) -> dict:
    """
    Build a complete result record dictionary for JSON persistence.

    Args:
        name: Participant's given name.
        surname: Participant's surname.
        dob: Date of birth string.
        student_id: Student ID string.
        answers: List of answer dictionaries.
        total_score: Total survey score.
        state: Interpreted psychological state name.
        description: Description of the state.
        domain_scores: Dictionary of per-domain average scores.

    Returns:
        A complete record dictionary ready for JSON serialisation.
    """
    return {
        "participant": {
            "name": name.strip(),
            "surname": surname.strip(),
            "date_of_birth": dob.strip(),
            "student_id": student_id.strip()
        },
        "results": {
            "total_score": total_score,
            "max_possible_score": len(QUESTIONS) * 4,
            "percentage": round((total_score / (len(QUESTIONS) * 4)) * 100, 1),
            "psychological_state": state,
            "description": description,
            "domain_scores": domain_scores
        },
        "answers": answers,
        "metadata": {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "version": VERSION,
            "total_questions": len(QUESTIONS)
        }
    }


# =============================================================================
# SECTION 5: GUI APPLICATION CLASS (Tkinter)
# =============================================================================

class SelfCareSurveyApp:
    """
    Main GUI application for the Self-Care Activity Scheduling
    and Emotional Balance Survey.

    The application has three screens:
      1. Registration Screen — collect and validate personal details
      2. Survey Screen — present questions with radio-button options
      3. Results Screen — display scores, interpretation, and save option
    """

    # Colour palette
    BG_COLOUR = "#F0F4F8"
    CARD_BG = "#FFFFFF"
    PRIMARY = "#2C3E50"
    SECONDARY = "#5D6D7E"
    ACCENT = "#3498DB"

    def __init__(self, root):
        """Initialise the application window and build the first screen."""
        self.root = root
        self.root.title(
            "Self-Care Activity Scheduling and Emotional Balance Survey"
        )
        self.root.geometry("860x680")
        self.root.resizable(True, True)
        self.root.configure(bg=self.BG_COLOUR)

        # Configure ttk styles
        self._configure_styles()

        # Tkinter variables for user input
        self.name_var = tk.StringVar()
        self.surname_var = tk.StringVar()
        self.dob_var = tk.StringVar()
        self.sid_var = tk.StringVar()

        # Survey answer variables (one IntVar per question)
        self.answer_vars = []

        # Store the final result record
        self.record = {}

        # Show the registration screen
        self._build_registration_screen()

    def _configure_styles(self):
        """Configure ttk widget styles for a professional appearance."""
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Title.TLabel",
                        font=("Segoe UI", 17, "bold"),
                        background=self.BG_COLOUR,
                        foreground=self.PRIMARY)
        style.configure("Subtitle.TLabel",
                        font=("Segoe UI", 11),
                        background=self.BG_COLOUR,
                        foreground=self.SECONDARY)
        style.configure("Field.TLabel",
                        font=("Segoe UI", 10),
                        background=self.BG_COLOUR)
        style.configure("Action.TButton",
                        font=("Segoe UI", 11, "bold"),
                        padding=8)
        style.configure("Small.TButton",
                        font=("Segoe UI", 10),
                        padding=6)

    # -----------------------------------------------------------------
    # SCREEN 1: Registration
    # -----------------------------------------------------------------

    def _build_registration_screen(self):
        """Build the registration screen for collecting personal details."""
        self._clear_window()

        outer = ttk.Frame(self.root, padding=40)
        outer.pack(fill="both", expand=True)

        # Title
        ttk.Label(
            outer,
            text="Self-Care & Emotional Balance Survey",
            style="Title.TLabel"
        ).pack(pady=(0, 4))
        ttk.Label(
            outer,
            text="Please enter your details below to begin the survey.",
            style="Subtitle.TLabel"
        ).pack(pady=(0, 30))

        # Form fields
        form_frame = ttk.Frame(outer)
        form_frame.pack()

        field_definitions = [
            ("Given Name:", self.name_var),
            ("Surname:", self.surname_var),
            ("Date of Birth (YYYY-MM-DD):", self.dob_var),
            ("Student ID (digits only):", self.sid_var),
        ]
        for row_idx, (label_text, variable) in enumerate(field_definitions):
            ttk.Label(
                form_frame, text=label_text, style="Field.TLabel"
            ).grid(row=row_idx, column=0, sticky="w", pady=10, padx=(0, 20))
            entry = ttk.Entry(
                form_frame, textvariable=variable, width=32,
                font=("Segoe UI", 11)
            )
            entry.grid(row=row_idx, column=1, pady=10)

        # Start button
        ttk.Button(
            outer, text="Start Survey",
            style="Action.TButton",
            command=self._on_start_clicked
        ).pack(pady=35)

        # Version label
        ttk.Label(
            outer,
            text=f"Version {VERSION}  |  Topic 151: Self-Care Activity "
                 f"Scheduling and Emotional Balance",
            style="Subtitle.TLabel"
        ).pack(side="bottom")

    def _on_start_clicked(self):
        """
        Validate personal details (INPUT stage) and proceed to the survey.
        Uses the validation functions from Section 2.
        """
        errors = []
        if not validate_name(self.name_var.get()):
            errors.append(
                "Given name is invalid (must not be empty or contain digits)."
            )
        if not validate_name(self.surname_var.get()):
            errors.append(
                "Surname is invalid (must not be empty or contain digits)."
            )
        if not validate_date_of_birth(self.dob_var.get()):
            errors.append(
                "Date of birth is invalid. Use YYYY-MM-DD format "
                "and ensure it is a past date."
            )
        if not validate_student_id(self.sid_var.get()):
            errors.append(
                "Student ID must contain only digits and cannot be empty."
            )

        if errors:
            messagebox.showerror(
                "Validation Error",
                "Please correct the following:\n\n" + "\n".join(errors)
            )
        else:
            self._build_survey_screen()

    # -----------------------------------------------------------------
    # SCREEN 2: Survey Questions
    # -----------------------------------------------------------------

    def _build_survey_screen(self):
        """Build the scrollable survey screen with all questions."""
        self._clear_window()

        # --- Header ---
        header = ttk.Frame(self.root, padding=(20, 12))
        header.pack(fill="x")
        ttk.Label(
            header,
            text="Self-Care & Emotional Balance Survey",
            style="Title.TLabel"
        ).pack()
        ttk.Label(
            header,
            text=(f"Participant: {self.name_var.get().strip()} "
                  f"{self.surname_var.get().strip()}  |  "
                  f"ID: {self.sid_var.get().strip()}"),
            style="Subtitle.TLabel"
        ).pack(pady=(2, 0))

        # --- Scrollable area ---
        container = ttk.Frame(self.root)
        container.pack(fill="both", expand=True)

        canvas = tk.Canvas(
            container, bg=self.BG_COLOUR, highlightthickness=0
        )
        v_scrollbar = ttk.Scrollbar(
            container, orient="vertical", command=canvas.yview
        )
        inner_frame = ttk.Frame(canvas, padding=(25, 10))

        inner_frame.bind(
            "<Configure>",
            lambda event: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        canvas.create_window((0, 0), window=inner_frame, anchor="nw")
        canvas.configure(yscrollcommand=v_scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        v_scrollbar.pack(side="right", fill="y")

        # Mouse-wheel scrolling
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        canvas.bind_all("<MouseWheel>", _on_mousewheel)

        # --- Render each question ---
        self.answer_vars = []
        current_domain = ""

        for q_data in QUESTIONS:
            # Domain header
            if q_data["domain"] != current_domain:
                current_domain = q_data["domain"]
                domain_label = tk.Label(
                    inner_frame,
                    text=f"— {current_domain} —",
                    font=("Segoe UI", 11, "bold", "italic"),
                    bg=self.BG_COLOUR, fg=self.ACCENT,
                    anchor="w"
                )
                domain_label.pack(fill="x", pady=(14, 4), padx=5)

            # Question card
            card = tk.Frame(
                inner_frame, bg=self.CARD_BG,
                bd=1, relief="solid", padx=16, pady=12
            )
            card.pack(fill="x", pady=4, padx=5)

            q_label = tk.Label(
                card,
                text=f"Q{q_data['id']}. {q_data['question']}",
                font=("Segoe UI", 10, "bold"),
                bg=self.CARD_BG, fg=self.PRIMARY,
                wraplength=720, justify="left", anchor="w"
            )
            q_label.pack(fill="x", anchor="w")

            var = tk.IntVar(value=-1)  # -1 = unanswered
            self.answer_vars.append(var)

            for option_text, option_score in q_data["options"]:
                rb = tk.Radiobutton(
                    card, text=option_text,
                    variable=var, value=option_score,
                    font=("Segoe UI", 10),
                    bg=self.CARD_BG,
                    activebackground="#E8F4FD",
                    anchor="w", padx=20
                )
                rb.pack(fill="x", pady=1)

        # --- Submit button ---
        btn_frame = ttk.Frame(inner_frame, padding=(0, 12))
        btn_frame.pack(fill="x")
        ttk.Button(
            btn_frame,
            text="Submit Survey",
            style="Action.TButton",
            command=self._on_submit_clicked
        ).pack()

    def _on_submit_clicked(self):
        """
        Process submitted answers (PROCESS stage):
        check completeness, calculate scores, interpret results.
        """
        # Check that all questions are answered
        unanswered = []
        for idx, var in enumerate(self.answer_vars):
            if var.get() == -1:
                unanswered.append(idx + 1)

        if unanswered:
            messagebox.showwarning(
                "Incomplete Survey",
                f"Please answer all questions before submitting.\n\n"
                f"Unanswered questions: "
                f"{', '.join(str(n) for n in unanswered)}"
            )
            return

        # Collect answer scores
        answer_scores = [var.get() for var in self.answer_vars]

        # Build answers list with full detail
        answers_list = []
        for idx, q_data in enumerate(QUESTIONS):
            selected_score = answer_scores[idx]
            selected_label = ""
            for label, score in q_data["options"]:
                if score == selected_score:
                    selected_label = label
                    break
            answers_list.append({
                "question_id": q_data["id"],
                "domain": q_data["domain"],
                "question": q_data["question"],
                "selected_option": selected_label,
                "score": selected_score
            })

        # PROCESS: calculate and interpret
        try:
            total_score = calculate_total_score(answer_scores)
        except ValueError as error:
            messagebox.showerror("Calculation Error", str(error))
            return

        state = interpret_score(total_score)
        description = get_state_description(state)
        domain_scores = calculate_domain_scores(answers_list)

        # Build the result record for persistence
        self.record = build_result_record(
            name=self.name_var.get(),
            surname=self.surname_var.get(),
            dob=self.dob_var.get(),
            student_id=self.sid_var.get(),
            answers=answers_list,
            total_score=total_score,
            state=state,
            description=description,
            domain_scores=domain_scores
        )

        # Show the results screen (OUTPUT stage)
        self._build_results_screen()

    # -----------------------------------------------------------------
    # SCREEN 3: Results
    # -----------------------------------------------------------------

    def _build_results_screen(self):
        """Build the results screen (OUTPUT stage) showing scores."""
        self._clear_window()

        # Scrollable container for results
        container = ttk.Frame(self.root)
        container.pack(fill="both", expand=True)

        canvas = tk.Canvas(container, bg=self.BG_COLOUR, highlightthickness=0)
        v_scrollbar = ttk.Scrollbar(
            container, orient="vertical", command=canvas.yview
        )
        frame = ttk.Frame(canvas, padding=30)
        frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        canvas.create_window((0, 0), window=frame, anchor="nw")
        canvas.configure(yscrollcommand=v_scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        v_scrollbar.pack(side="right", fill="y")

        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        canvas.bind_all("<MouseWheel>", _on_mousewheel)

        res = self.record["results"]
        participant = self.record["participant"]
        state_colour = STATE_COLOURS.get(
            res["psychological_state"], "#333333"
        )

        # Title
        ttk.Label(
            frame, text="Survey Complete!",
            style="Title.TLabel"
        ).pack(pady=(0, 10))

        # Participant info
        info_text = (
            f"Participant: {participant['name']} {participant['surname']}  |  "
            f"ID: {participant['student_id']}  |  "
            f"DOB: {participant['date_of_birth']}"
        )
        ttk.Label(frame, text=info_text, style="Subtitle.TLabel").pack()

        # Score summary
        score_text = (
            f"Total Score: {res['total_score']} / "
            f"{res['max_possible_score']}  "
            f"({res['percentage']}%)"
        )
        tk.Label(
            frame, text=score_text,
            font=("Segoe UI", 13, "bold"),
            bg=self.BG_COLOUR, fg=self.PRIMARY
        ).pack(pady=(15, 5))

        # State label
        tk.Label(
            frame,
            text=res["psychological_state"],
            font=("Segoe UI", 16, "bold"),
            bg=self.BG_COLOUR, fg=state_colour
        ).pack(pady=5)

        # Score bar
        bar_canvas = tk.Canvas(
            frame, width=520, height=28,
            bg=self.BG_COLOUR, highlightthickness=0
        )
        bar_canvas.pack(pady=8)
        bar_canvas.create_rectangle(
            2, 2, 518, 26, fill="#E0E0E0", outline="#CCCCCC"
        )
        fill_width = int((res["percentage"] / 100) * 516)
        if fill_width > 0:
            bar_canvas.create_rectangle(
                2, 2, 2 + fill_width, 26,
                fill=state_colour, outline=""
            )

        # Description
        tk.Label(
            frame, text=res["description"],
            font=("Segoe UI", 10), bg=self.BG_COLOUR, fg=self.SECONDARY,
            wraplength=600, justify="center"
        ).pack(pady=(5, 15))

        # Domain breakdown
        tk.Label(
            frame, text="Score Breakdown by Domain",
            font=("Segoe UI", 12, "bold"),
            bg=self.BG_COLOUR, fg=self.PRIMARY
        ).pack(pady=(10, 5))

        domain_frame = tk.Frame(frame, bg=self.CARD_BG, bd=1, relief="solid",
                                padx=20, pady=15)
        domain_frame.pack(fill="x", padx=30)

        for domain_name, avg_score in res["domain_scores"].items():
            row = tk.Frame(domain_frame, bg=self.CARD_BG)
            row.pack(fill="x", pady=3)
            tk.Label(
                row, text=domain_name,
                font=("Segoe UI", 10), bg=self.CARD_BG,
                fg=self.PRIMARY, width=30, anchor="w"
            ).pack(side="left")
            # Mini bar for domain
            d_canvas = tk.Canvas(
                row, width=200, height=16,
                bg=self.CARD_BG, highlightthickness=0
            )
            d_canvas.pack(side="left", padx=10)
            d_canvas.create_rectangle(0, 0, 200, 16, fill="#ECEFF1", outline="")
            d_fill = int((avg_score / 4) * 200)
            d_colour = "#27AE60" if avg_score <= 1.3 else (
                "#F39C12" if avg_score <= 2.6 else "#E74C3C"
            )
            if d_fill > 0:
                d_canvas.create_rectangle(0, 0, d_fill, 16,
                                          fill=d_colour, outline="")
            tk.Label(
                row, text=f"{avg_score:.1f} / 4.0",
                font=("Segoe UI", 9), bg=self.CARD_BG, fg=self.SECONDARY
            ).pack(side="left")

        # Action buttons
        btn_row = ttk.Frame(frame, padding=(0, 20))
        btn_row.pack()

        ttk.Button(
            btn_row, text="Save Results (JSON)",
            style="Small.TButton",
            command=self._on_save_clicked
        ).pack(side="left", padx=8)

        ttk.Button(
            btn_row, text="New Survey",
            style="Small.TButton",
            command=self._on_new_survey_clicked
        ).pack(side="left", padx=8)

        ttk.Button(
            btn_row, text="Exit",
            style="Small.TButton",
            command=self.root.quit
        ).pack(side="left", padx=8)

    def _on_save_clicked(self):
        """Save results to JSON using the output function from Section 4."""
        default_filename = (
            f"{self.record['participant']['student_id']}_result.json"
        )
        filepath = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON files", "*.json")],
            initialfile=default_filename
        )
        if filepath:
            success = save_results_to_json(filepath, self.record)
            if success:
                messagebox.showinfo(
                    "Saved Successfully",
                    f"Results saved to:\n{filepath}"
                )
            else:
                messagebox.showerror(
                    "Save Error",
                    "An error occurred while saving. Please try again."
                )

    def _on_new_survey_clicked(self):
        """Reset the application for a new survey participant."""
        self.name_var.set("")
        self.surname_var.set("")
        self.dob_var.set("")
        self.sid_var.set("")
        self.answer_vars = []
        self.record = {}
        self._build_registration_screen()

    # -----------------------------------------------------------------
    # Utility
    # -----------------------------------------------------------------

    def _clear_window(self):
        """Remove all child widgets from the root window."""
        for widget in self.root.winfo_children():
            widget.destroy()


# =============================================================================
# SECTION 6: UNIT TESTS
# =============================================================================
# Run with: python self_care_survey_gui.py --test
# Tests verify the core INPUT, PROCESS, and OUTPUT functions.

class TestValidation(unittest.TestCase):
    """Tests for input validation functions (Section 2)."""

    def test_valid_name(self):
        self.assertTrue(validate_name("Alice"))
        self.assertTrue(validate_name("  Anna Maria  "))

    def test_invalid_name_empty(self):
        self.assertFalse(validate_name(""))
        self.assertFalse(validate_name("   "))

    def test_invalid_name_with_digits(self):
        self.assertFalse(validate_name("Alice123"))
        self.assertFalse(validate_name("9Bob"))

    def test_valid_dob(self):
        self.assertTrue(validate_date_of_birth("2000-05-15"))
        self.assertTrue(validate_date_of_birth("1995-12-31"))

    def test_invalid_dob_format(self):
        self.assertFalse(validate_date_of_birth("15-05-2000"))
        self.assertFalse(validate_date_of_birth("not-a-date"))
        self.assertFalse(validate_date_of_birth(""))

    def test_invalid_dob_future(self):
        self.assertFalse(validate_date_of_birth("2099-01-01"))

    def test_valid_student_id(self):
        self.assertTrue(validate_student_id("123456"))
        self.assertTrue(validate_student_id("  007  "))

    def test_invalid_student_id(self):
        self.assertFalse(validate_student_id(""))
        self.assertFalse(validate_student_id("abc"))
        self.assertFalse(validate_student_id("12.34"))


class TestProcessing(unittest.TestCase):
    """Tests for score calculation and interpretation functions (Section 3)."""

    def test_calculate_total_score(self):
        self.assertEqual(calculate_total_score([0, 1, 2, 3, 4]), 10)
        self.assertEqual(calculate_total_score([0, 0, 0]), 0)
        self.assertEqual(calculate_total_score([4, 4, 4]), 12)

    def test_calculate_total_score_empty(self):
        with self.assertRaises(ValueError):
            calculate_total_score([])

    def test_interpret_score_boundaries(self):
        self.assertEqual(interpret_score(0), "Excellent Emotional Balance")
        self.assertEqual(interpret_score(13), "Excellent Emotional Balance")
        self.assertEqual(interpret_score(14), "Good Emotional Balance")
        self.assertEqual(interpret_score(40), "Moderate Emotional Balance")
        self.assertEqual(interpret_score(80), "Critical Emotional Imbalance")

    def test_interpret_score_unknown(self):
        self.assertEqual(interpret_score(-5), "Unknown")
        self.assertEqual(interpret_score(999), "Unknown")

    def test_get_state_description(self):
        desc = get_state_description("Excellent Emotional Balance")
        self.assertIn("outstanding", desc)

    def test_get_state_description_unknown(self):
        desc = get_state_description("NonexistentState")
        self.assertEqual(desc, "No description available.")

    def test_calculate_domain_scores(self):
        answers = [
            {"domain": "Physical Self-Care", "score": 2},
            {"domain": "Physical Self-Care", "score": 4},
            {"domain": "Mindful Relaxation", "score": 0},
        ]
        result = calculate_domain_scores(answers)
        self.assertEqual(result["Physical Self-Care"], 3.0)
        self.assertEqual(result["Mindful Relaxation"], 0.0)


class TestPersistence(unittest.TestCase):
    """Tests for JSON save/load functions (Section 4)."""

    def setUp(self):
        self.test_file = "_test_result_temp.json"
        self.sample_data = {
            "participant": {"name": "Test", "student_id": "999"},
            "results": {"total_score": 25}
        }

    def tearDown(self):
        if os.path.exists(self.test_file):
            os.remove(self.test_file)

    def test_save_and_load(self):
        success = save_results_to_json(self.test_file, self.sample_data)
        self.assertTrue(success)
        loaded = load_results_from_json(self.test_file)
        self.assertEqual(loaded["results"]["total_score"], 25)

    def test_load_nonexistent_file(self):
        result = load_results_from_json("nonexistent_file.json")
        self.assertEqual(result, {})


# =============================================================================
# SECTION 7: ENTRY POINT
# =============================================================================

if __name__ == "__main__":
    # If --test flag is provided, run unit tests instead of the GUI
    if "--test" in sys.argv:
        sys.argv.remove("--test")  # Remove flag so unittest doesn't see it
        print("Running unit tests...\n")
        unittest.main(verbosity=2)
    else:
        # Launch the GUI application
        if not TKINTER_AVAILABLE:
            print("Error: Tkinter is not installed. Please install it to "
                  "run the GUI.\nTo run unit tests, use: python "
                  "self_care_survey_gui.py --test")
            sys.exit(1)
        root = tk.Tk()
        app = SelfCareSurveyApp(root)
        root.mainloop()
